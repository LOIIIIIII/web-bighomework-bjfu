window.addEventListener('load', function() {
  const elements = document.querySelector(".box");

  function change() {

      elements.classList.toggle("transformed-state");
  }
  elements.addEventListener("click", change);
    })