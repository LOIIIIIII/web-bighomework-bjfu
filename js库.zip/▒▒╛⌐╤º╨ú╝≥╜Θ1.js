window.addEventListener('load', function() {
const doc = document;

// 实际预览的图片的数组
const overviewImgs = doc.querySelectorAll('.overview-img');

// 遮罩层
const overlay = doc.querySelector('.overlay');

// 关闭按钮
const closeBtn = doc.querySelector('.close-btn');


// 视口中心坐标
const viewport_x = doc.body.clientWidth / 2;
const viewport_y = doc.body.clientHeight / 2;

overviewImgs.forEach((img, index) => {
    // 点击图片的事件
    img.addEventListener('click', () => {
        // 图片中心坐标（相对于视口）
        const img_x = img.getBoundingClientRect().left + (img.getBoundingClientRect().right - img.getBoundingClientRect().left) / 2;
        const img_y = img.getBoundingClientRect().top + (img.getBoundingClientRect().bottom - img.getBoundingClientRect().top) / 2;

        // 需要移动的距离
        const translate_x = viewport_x - img_x;
        const translate_y = viewport_y - img_y;

        if (translate_x === 0 && translate_y === 0) {
            return;
        }

        // 开始设置移动的样式和居中显示
        img.style.transform = `translate(${ translate_x }px, ${ translate_y }px)`;
        img.classList.add('overview-show'); // 显示预览图
        overlay.classList.add('overlay-show'); // 显示遮罩层
    });
});

// 关闭
closeBtn.addEventListener('click', e => {
    const imgShow = doc.querySelector('.overview-show');
    imgShow.classList.remove('overview-show'); // 隐藏图片
    imgShow.style.transform = 'translate(0, 0)'; // 位置复原
    overlay.classList.remove('overlay-show'); // 隐藏遮罩层
});
})