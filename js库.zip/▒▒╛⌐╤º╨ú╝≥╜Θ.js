window.addEventListener('load', function() {
    // 1. 获取元素
    var cloud = document.querySelector('.movercloud');
    var c_nav = document.querySelector('.nav');
    var lis = c_nav.querySelectorAll('li');
    const doc=document;
const navder=doc.querySelector("#navder");
const dbing=doc.querySelector(".little-bing");
console.log(dbing);
console.log(navder);
function displaynavder(entries){
    const entry=entries[0];
    if(entry.intersectionRatio!==0)
    {
        navder.classList.add('display');
    }else{
        navder.classList.remove('display');
    }
}

//交叉事件容器
const flag=new IntersectionObserver(displaynavder);
//监听事件
flag.observe(dbing);

    // 2. 给所有的小li绑定事件 
    // 这个current 做为筋斗云的起始位置
    var current = 0;
    for (var i = 0; i < lis.length; i++) {
        // (1) 鼠标经过把当前小li 的位置做为目标值
        lis[i].addEventListener('mouseenter', function() {
            animate(cloud, this.offsetLeft);
        });
        // (2) 鼠标离开就回到起始的位置 
        lis[i].addEventListener('mouseleave', function() {
            animate(cloud, current);
        });
        // (3) 当我们鼠标点击，就把当前位置做为目标值
        lis[i].addEventListener('click', function() {
            current = this.offsetLeft;
        });
    }
})
