const inputs = document.querySelectorAll('.input_field');
const toggle_btn = document.querySelectorAll('.toggle');
const main=document.querySelector('main');
const bullets=document.querySelectorAll('.bullets span');
const images=document.querySelectorAll('.image');
inputs.forEach(inp => {
    
    inp.addEventListener('focus', () => {
        inp.classList.add('active');
    });
    
    inp.addEventListener('blur', () => {
        if (inp.value != '') return ;
        inp.classList.remove('active');    
    });
});

toggle_btn.forEach(btn => {
    btn.addEventListener('click', () => {
        main.classList.toggle('sign_up_mode');
    });
});

function moveslider(){
    let index=this.dataset.value;
    let currentImage=document.querySelector(`.img-${index}`);
    console.log(index);
    images.forEach(img => {
        img.classList.remove('show');
    });
    currentImage.classList.add('show');
    const text_Slider=document.querySelector('.text_group');
    text_Slider.style.transform=`translateY(${-(index-1)*2.2}rem)`;
    bullets.forEach(bullet => {
        bullet.classList.remove('active');
    });
    this.classList.add('active');
}
bullets.forEach((bullet,index) => {
    bullet.addEventListener('click',moveslider);
})