const carousel = document.querySelector(".carousel");
const leftArror = document.querySelector(".left-arror");
const rightArror = document.querySelector(".right-arror");
const allItems = document.querySelectorAll(".item");
const dots = document.querySelector(".dots");

//类名数组：用于后面给图片添加类名
const classArr = ["one", "two", "three", "four", "five", "six"];

//记录当前小圆点
let currentDotIndex = 0;



//右侧跳转函数
const handleRight = () => {
    //复制最后一个元素，追加到数组前面
    classArr.unshift(classArr[allItems.length - 1]);
    //删除最后一个元素
    classArr.pop();
    //利用循环重新给每个图片添加属性
    for (let i = 0; i < allItems.length; i++) {
        allItems[i].className = `item ${classArr[i]}`;
        //如果item的类名中包含one，代表中间图片，加上active类名
        if(allItems[i].className.includes("one")){
            allItems[i].classList.add("active");
        }
    }
    currentDotIndex++;
    //如果当前小圆点的下标大于等于小圆点的长度，则重置为0
    if(currentDotIndex>=allDot.length){
        currentDotIndex=0;
    }
    document.querySelector(".show").classList.remove("show");
    //给当前点击的小圆点添加show类名
    allDot[currentDotIndex].classList.add("show");
}

//右侧按钮
rightArror.addEventListener("click", handleRight);


//左侧跳转函数
const handleLeft = () => {
    //复制第一个元素，追加到数组后面
    classArr.push(classArr[0]);
    //删除第一个元素
    classArr.shift();
    //重新赋值
    for (let i = 0; i < allItems.length; i++) {
        allItems[i].className = `item ${classArr[i]}`;
        //如果item的类名中包含one，代表中间图片，加上active类名
        if(allItems[i].className.includes("one")){
            allItems[i].classList.add("active");
        }
    }
    currentDotIndex--;
    //如果当前小圆点的下标小于0，则重置为小圆点的长度-1
    if(currentDotIndex<0){
        currentDotIndex=allDot.length-1;
    }
    document.querySelector(".show").classList.remove("show");
    //给当前点击的小圆点添加show类名
    allDot[currentDotIndex].classList.add("show");
}


//左侧按钮
leftArror.addEventListener("click", handleLeft);

//小圆点点击事件
const handleDot = (e) => {
    //获取点击的小圆点的下标
    const currentClickIndex = +e.target.getAttribute("data-index");
    document.querySelector(".show").classList.remove("show");
    //给当前点击的小圆点添加show类名
    allDot[currentClickIndex].classList.add("show");
    //获取类名为one的下标
    const centerElement=classArr.indexOf("one");
    //获取当前点击的小圆点与类名为one的下标的差值
    let diff=Math.max(currentClickIndex,centerElement)-Math.min(currentClickIndex,centerElement);
    //如果点击的小圆点的下标大于中间元素类名one的下标，则触发handleRight函数
    if(currentClickIndex>centerElement){
        for(let i=0;i<diff;i++){
            handleRight();
        }
    }else{
        //否则触发handleLeft函数
        for(let i=0;i<diff;i++){
            handleLeft();
        }
    }
}
//获取所有小圆点
let allDot=null
//自动生成小圆点
const createDots = () => {
    for(let i=0;i<allItems.length;i++){
        const li=document.createElement("li");
        li.setAttribute("class","dot");
        //添加自定义属性，代表下标
        li.setAttribute("data-index",`${i}`);
        li.addEventListener("click",handleDot);
        //追加到dots中
        dots.appendChild(li);
    }
    //获取所有小圆点
    allDot=document.querySelectorAll(".dot");
    //第一个添加上show类名
    allDot[0].classList.add("show");
}

//调用生成小圆点函数
createDots();

let timer=null;

//自动轮播
timer=setInterval(()=>{
    rightArror.click();
},2000);

//鼠标移入移出事件
carousel.addEventListener("mouseenter",()=>{
    clearInterval(timer);
})
carousel.addEventListener("mouseleave",()=>{
    timer=setInterval(handleRight,2000);
})    

const aTag = document.querySelector('a');
aTag.addEventListener('click', (event) => {
  event.preventDefault();
  const targetId = aTag.getAttribute('href');
  const targetElement = document.querySelector(targetId);
  targetElement.scrollIntoView({ behavior: 'smooth' });
});